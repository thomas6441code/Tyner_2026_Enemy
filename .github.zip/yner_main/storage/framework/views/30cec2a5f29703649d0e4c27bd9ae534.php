<?php echo e($slot); ?>

<?php /**PATH C:\Users\Thomas-6441\Desktop\AuroraEnemy\Tyner_2026\yner_main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>